Dynamic Lyrics

Group Members: Westley Mixon, Eric Munoz, Harlen Cheer, Logan Louks

Class: CST 205 - TTH 10am-12pm

May 15th, 2017

How to run:

Everything was run on a linux virtual machine (Ubuntu)
Install PyQt5, Pafy https://pypi.python.org/pypi/pafy, Urlib https://docs.python.org/2/library/urllib.html, and VLC.
Open a terminal, cd to directory, run python3 Lyrics.py

https://github.com/bigbrotherx52/205Projecr3-DynoLyrica/

Planning:

Want to make it so you can download lyrics from Youtube, and record as a video.